# Eggie DocuFlow V1.4.0 发布说明

## 下载安装

- [Mac 版下载：Apple 芯片，macOS 11 或以上](https://github.com/huangchong-4806/Eggie-DocuFlow/releases/download/v1.4.0/EggieDocuFlow_V1.4.0_mac.zip)
- [Windows 版下载：Windows 10/11 64 位](https://github.com/huangchong-4806/Eggie-DocuFlow/releases/download/v1.4.0/EggieDocuFlow_V1.4.0_Windows_x64_Setup.exe)

普通用户只需下载上面对应的安装包，不要下载页面底部由 GitHub 自动生成的 Source code。

软件无需安装 Python。Excel 与 PDF 默认在本机处理并保留原文件；文件改名必须先预览再执行。

> Mac 版暂未经过 Apple 公证。首次打开被阻止时，请在 Finder 中右键软件，选择“打开”，再确认“打开”。
>
> 部分 Windows 电脑可能显示“Windows 已保护你的电脑”或“未知发布者”。如果出现，请确认安装包来自本页，再选择“更多信息”→“仍要运行”。

## 本次新增

- 批量处理中心：扫描 PDF 文件夹，处理前显示页数、扫描页和建议操作；单文件失败不会中断整个任务，可只重试失败项。
- Excel 数据清理：可预览并清理空白行、文字前后空格、重复数据，并统一已有日期和数字的显示格式。
- 智能改名：根据发票或合同内容生成文件名建议，并标记内容完全相同的文件。无法可靠识别时保留原名。
- PDF 水印与页码：可调整文字、透明度、角度、位置和页码起始值。
- PDF 密码：可设置打开密码，或在已知原密码时生成无密码副本。密码不保存、不写入日志。
- 可搜索 PDF：保留原页面图像，只对扫描页在用户确认后调用所选 OCR 平台并加入文字层。
- PDF 文字对比：在本机将两份可搜索 PDF 生成 HTML 差异报告。
- 界面更新：统一首页、工具页、按钮、表格和设置页的浅色玻璃风格，减少拥挤和重叠。

## 安全与兼容性

- 所有新功能都保留原文件，只生成新结果。
- 所有改名和数据清理都先显示预览。
- 扫描页仅在用户配置自己的 OCR 密钥并确认页码后发送。
- OCR 密钥保存在当前用户的本机配置区，不包含在安装包中。
- 正式 macOS 包为 Apple 芯片版本，最低支持 macOS 11。
- 本版未做 Apple 公证；首次打开被阻止时，请在 Finder 中右键软件并选择“打开”。

## 正式文件

- `EggieDocuFlow_V1.4.0_mac.zip`
- 解压 ZIP 后得到 `EggieDocuFlow_V1.4.0_mac.app`
- `EggieDocuFlow_V1.4.0_Windows_x64_Setup.exe`

## 验证信息

- 自动检查：打包前执行 137 项检查。
- 界面检查：打包前检查主要页面截图的重叠、文字和按钮状态。
- 文件检查：对代表性 PDF、HTML 和 Excel 结果进行实际打开测试。
- Windows 验证：已在 Windows 11 虚拟机完成安装并实际启动，界面正常，版本显示为 1.4.0。
- macOS ZIP 大小：44 MiB（Finder 显示约 45 MB）。
- macOS ZIP SHA-256：`8d06e758614b0fe7221bdf9142d5b133c12d5df06cd63d9b7e6b8d56aad5f7a3`
- Windows 安装包大小：约 46 MiB。
- Windows 安装包 SHA-256：`769d378426cd454ddf93c0c4d6b46270a49eba6494c1c02cdad0cbe5b073fa67`
