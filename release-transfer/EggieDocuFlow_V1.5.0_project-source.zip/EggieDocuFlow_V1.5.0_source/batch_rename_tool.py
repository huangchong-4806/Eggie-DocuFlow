import ctypes
import errno
import os
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


MACOS_ILLEGAL_NAME_CHARS = {"/", "\0", ":"}
WINDOWS_ILLEGAL_NAME_CHARS = {"/", "\\", "\0", ":", "*", "?", '"', "<", ">", "|"}
WINDOWS_RESERVED_STEMS = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}
MACOS_RENAME_EXCL = 0x00000004


if sys.platform == "darwin":
    _macos_renamex_np = ctypes.CDLL(None, use_errno=True).renamex_np
    _macos_renamex_np.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_uint,
    ]
    _macos_renamex_np.restype = ctypes.c_int
else:
    _macos_renamex_np = None


@dataclass(frozen=True)
class RenameOptions:
    find_text: str = ""
    replace_text: str = ""
    delete_text: str = ""
    trim_start_count: int = 0
    trim_end_count: int = 0
    prefix: str = ""
    suffix: str = ""
    extension: str = ""
    numbering_enabled: bool = False
    number_start: int = 1
    number_digits: int = 3


@dataclass(frozen=True)
class RenamePreview:
    source_path: str
    target_path: str
    status: str
    message: str
    will_rename: bool
    blocked: bool


@dataclass(frozen=True)
class RenameAction:
    source_path: str
    target_path: str
    status: str
    error: str = ""


@dataclass(frozen=True)
class RenameApplyResult:
    log_file: str
    actions: tuple

    @property
    def success_count(self):
        return sum(1 for action in self.actions if action.status == "成功")

    @property
    def failed_count(self):
        return sum(1 for action in self.actions if action.status == "失败")

    @property
    def skipped_count(self):
        return sum(1 for action in self.actions if action.status == "跳过")


def discover_rename_files(folder):
    files = []
    for root, directory_names, filenames in os.walk(folder):
        directory_names[:] = sorted(
            (
                name
                for name in directory_names
                if not name.startswith(".") and name != "__MACOSX"
            ),
            key=str.casefold,
        )
        for filename in sorted(filenames, key=str.casefold):
            if filename.startswith("."):
                continue
            path = Path(root, filename)
            if path.is_file():
                files.append(str(path.resolve()))
    return files


def _illegal_name_chars(platform_name=None):
    platform_name = platform_name or sys.platform
    return (
        WINDOWS_ILLEGAL_NAME_CHARS
        if platform_name == "win32"
        else MACOS_ILLEGAL_NAME_CHARS
    )


def _normalized_extension(extension, original_suffix, platform_name=None):
    extension = extension.strip()
    if not extension:
        return original_suffix
    if extension == ".":
        raise ValueError("新后缀不能只填写一个点。")
    if any(character in extension for character in _illegal_name_chars(platform_name)):
        raise ValueError("新后缀包含不允许使用的字符。")
    return extension if extension.startswith(".") else f".{extension}"


def _validate_name(filename, platform_name=None):
    if not filename.strip():
        raise ValueError("新文件名不能为空。")
    if any(character in filename for character in _illegal_name_chars(platform_name)):
        raise ValueError("新文件名包含不允许使用的字符。")
    if platform_name == "win32":
        original_stem = filename.split(".", 1)[0]
        stem = original_stem.rstrip(" .")
        if not stem:
            raise ValueError("新文件名不能为空。")
        if original_stem != stem or filename.endswith((".", " ")):
            raise ValueError("Windows 文件名不能以空格或点结尾。")
        if stem.upper() in WINDOWS_RESERVED_STEMS:
            raise ValueError("新文件名是 Windows 系统保留名称。")


def _target_for(source_path, options, sequence_number):
    source = Path(source_path)
    stem = source.stem
    if options.find_text:
        stem = stem.replace(options.find_text, options.replace_text)
    if options.delete_text:
        stem = stem.replace(options.delete_text, "")
    if options.trim_start_count:
        stem = stem[max(0, options.trim_start_count) :]
    if options.trim_end_count:
        trim_count = max(0, options.trim_end_count)
        stem = stem[:-trim_count] if trim_count < len(stem) else ""
    stem = f"{options.prefix}{stem}{options.suffix}"
    if options.numbering_enabled:
        digits = max(1, options.number_digits)
        stem = f"{stem}_{sequence_number:0{digits}d}"
    if not stem.strip():
        raise ValueError("新文件名不能为空。")

    extension = _normalized_extension(options.extension, source.suffix)
    target_name = f"{stem}{extension}"
    _validate_name(target_name)
    return source.with_name(target_name)


def _path_key(path):
    return str(Path(path).parent.resolve() / Path(path).name).casefold()


def _same_file(left, right):
    try:
        return os.path.samefile(left, right)
    except OSError:
        return False


def _same_entry(left, right):
    try:
        left_stat = os.lstat(left)
        right_stat = os.lstat(right)
    except OSError:
        return False
    return (left_stat.st_dev, left_stat.st_ino) == (
        right_stat.st_dev,
        right_stat.st_ino,
    )


def _rename_without_overwrite(source_path, target_path):
    source = Path(source_path)
    target = Path(target_path)
    if _macos_renamex_np is not None:
        result = _macos_renamex_np(
            os.fsencode(source),
            os.fsencode(target),
            MACOS_RENAME_EXCL,
        )
        if result == 0:
            return
        error_number = ctypes.get_errno()
        if error_number == errno.EEXIST:
            raise FileExistsError(
                error_number,
                f"目标文件已存在：{target}",
                str(target),
            )
        raise OSError(
            error_number,
            os.strerror(error_number),
            str(target),
        )

    if _same_file(source, target):
        source.rename(target)
        return

    try:
        os.link(source, target, follow_symlinks=False)
    except FileExistsError as error:
        raise FileExistsError(f"目标文件已存在：{target}") from error
    except OSError as error:
        link_restriction_errors = {
            errno.EINVAL,
            errno.EPERM,
            errno.EXDEV,
            getattr(errno, "EOPNOTSUPP", errno.EINVAL),
        }
        if error.errno not in link_restriction_errors:
            raise
        source.rename(target)
        return

    if not _same_entry(source, target):
        target.unlink(missing_ok=True)
        raise OSError("源文件在改名过程中发生变化，已停止处理。")

    try:
        source.unlink()
    except OSError:
        try:
            if _same_entry(source, target):
                target.unlink()
        except OSError:
            pass
        raise


def _build_previews(rows, target_counts):
    previews = []
    for source_path, target_path, error, key in rows:
        if error:
            previews.append(
                RenamePreview(source_path, target_path, "不可改名", error, False, True)
            )
            continue

        if target_counts.get(key, 0) > 1:
            previews.append(
                RenamePreview(
                    source_path,
                    target_path,
                    "文件名重复",
                    "多个文件会改成同一个名字。",
                    False,
                    True,
                )
            )
            continue

        if Path(target_path).exists() and not _same_file(source_path, target_path):
            previews.append(
                RenamePreview(
                    source_path,
                    target_path,
                    "目标已存在",
                    "目标文件夹里已有同名文件。",
                    False,
                    True,
                )
            )
            continue

        will_rename = os.path.abspath(source_path) != os.path.abspath(target_path)
        previews.append(
            RenamePreview(
                source_path,
                target_path,
                "可以改名" if will_rename else "无需改名",
                "",
                will_rename,
                False,
            )
        )

    return tuple(previews)


def preview_renames(files, options):
    absolute_files = [os.path.abspath(filename) for filename in files]
    rows = []
    target_counts = {}

    for index, source_path in enumerate(absolute_files):
        try:
            if not Path(source_path).is_file():
                raise ValueError("源文件不存在。")
            target_path = os.path.abspath(
                _target_for(
                    source_path,
                    options,
                    options.number_start + index,
                )
            )
            key = _path_key(target_path)
            target_counts[key] = target_counts.get(key, 0) + 1
            rows.append((source_path, target_path, "", key))
        except ValueError as error:
            rows.append((source_path, source_path, str(error), ""))
    return _build_previews(rows, target_counts)


def preview_explicit_renames(pairs):
    rows = []
    target_counts = {}
    for source_path, target_path in pairs:
        source_path = os.path.abspath(source_path)
        target_path = os.path.abspath(target_path)
        try:
            if not Path(source_path).is_file():
                raise ValueError("源文件不存在。")
            if Path(source_path).parent != Path(target_path).parent:
                raise ValueError("智能改名不能移动文件。")
            _validate_name(Path(target_path).name)
            key = _path_key(target_path)
            target_counts[key] = target_counts.get(key, 0) + 1
            rows.append((source_path, target_path, "", key))
        except ValueError as error:
            rows.append((source_path, source_path, str(error), ""))
    return _build_previews(rows, target_counts)


def _log_path(folder):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path(folder) / f"批量改名日志_{timestamp}.txt"


def _open_action_log(folder):
    base = _log_path(folder)
    for number in range(10000):
        path = base if number == 0 else base.with_name(f"{base.stem}_{number}{base.suffix}")
        try:
            return path, path.open("x", encoding="utf-8")
        except FileExistsError:
            continue
    raise FileExistsError("无法创建不重复的改名日志，请稍后重试。")


def _write_action_log(handle, index, preview, status, error, metadata=None):
    handle.write(f"序号：{index}\n")
    handle.write(f"处理时间：{datetime.now().isoformat(timespec='seconds')}\n")
    handle.write(f"原文件路径：{preview.source_path}\n")
    handle.write(f"新文件路径：{preview.target_path}\n")
    handle.write(f"原文件名：{Path(preview.source_path).name}\n")
    handle.write(f"新文件名：{Path(preview.target_path).name}\n")
    handle.write(f"处理结果：{status}\n")
    handle.write(f"失败原因：{error}\n")
    for key, value in (metadata or {}).items():
        clean_value = str(value).replace("\r", " ").replace("\n", " ")
        handle.write(f"{key}：{clean_value}\n")
    handle.write("-" * 60 + "\n")


def apply_renames(
    previews,
    log_folder=None,
    progress_callback=None,
    metadata_by_source=None,
):
    if any(preview.blocked for preview in previews):
        raise ValueError("预览中还有不能改名的文件，请先处理后再执行。")
    if not previews:
        raise ValueError("没有需要处理的文件。")

    log_folder = Path(log_folder or Path(previews[0].source_path).parent)
    log_folder.mkdir(parents=True, exist_ok=True)
    log_file, log_handle = _open_action_log(log_folder)
    actions = []

    with log_handle as handle:
        handle.write("批量改名操作日志\n")
        handle.write(f"生成时间：{datetime.now().isoformat(timespec='seconds')}\n")
        handle.write(f"文件数量：{len(previews)}\n")
        handle.write("=" * 60 + "\n")
        for index, preview in enumerate(previews, start=1):
            if progress_callback:
                progress_callback(
                    index - 1,
                    len(previews),
                    f"正在处理第 {index} / {len(previews)} 个："
                    f"{Path(preview.source_path).name}",
                )
            status = "跳过"
            error = ""
            if preview.will_rename:
                try:
                    _rename_without_overwrite(
                        preview.source_path,
                        preview.target_path,
                    )
                    status = "成功"
                except OSError as rename_error:
                    status = "失败"
                    error = str(rename_error)

            _write_action_log(
                handle,
                index,
                preview,
                status,
                error,
                (metadata_by_source or {}).get(preview.source_path),
            )
            actions.append(
                RenameAction(preview.source_path, preview.target_path, status, error)
            )
            if progress_callback:
                progress_callback(
                    index,
                    len(previews),
                    f"已处理 {index} / {len(previews)} 个文件",
                )

    return RenameApplyResult(str(log_file), tuple(actions))
